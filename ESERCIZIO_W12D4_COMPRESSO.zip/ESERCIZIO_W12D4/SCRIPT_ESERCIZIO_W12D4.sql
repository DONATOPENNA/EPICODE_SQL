-- Creazione del database
CREATE DATABASE IF NOT EXISTS Toys_Group;

-- Utilizzo del database
USE Toys_Group;

-- Creazione delle tabelle
CREATE TABLE Product (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    Nome VARCHAR(255),
    Categoria VARCHAR(255)
);

CREATE TABLE Region (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    Nome VARCHAR(255),
    Stato VARCHAR(255)
);

CREATE TABLE Sales (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    ID_Prodotto INT,
    ID_Regione INT,
    Data DATE,
    Fatturato DECIMAL(10,2),
    FOREIGN KEY (ID_Prodotto) REFERENCES Product(ID),
    FOREIGN KEY (ID_Regione) REFERENCES Region(ID)
);

-- Inserimento dei dati di esempio
INSERT INTO Product (Nome, Categoria) VALUES
('Palla', 'Giocattolo'),
('Auto', 'Giocattolo'),
('Bambola', 'Giocattolo'),
('Treno', 'Giocattolo'),
('Puzzle', 'Gioco Educativo'),
('Libro', 'Gioco Educativo'),
('Lego', 'Costruzioni'),
('Robot', 'Elettronico'),
('Peluche', 'Giocattolo'),      -- Prodotto invenduto
('Monopattino', 'Elettronico'); -- Prodotto invenduto

INSERT INTO Region (Nome, Stato) VALUES
('Nord', 'Italia'),
('Sud', 'Italia'),
('Est', 'Italia'),
('Ovest', 'Italia'),
('Centro', 'Italia');

INSERT INTO Sales (ID_Prodotto, ID_Regione, Data, Fatturato) VALUES
(1, 1, '2024-01-01', 100.00),
(2, 2, '2024-01-02', 150.00),
(3, 3, '2024-01-03', 200.00),
(4, 4, '2024-02-01', 250.00),
(5, 5, '2024-02-15', 300.00),
(1, 2, '2024-03-01', 120.00),
(2, 3, '2024-03-05', 160.00),
(6, 4, '2024-03-10', 180.00),
(7, 5, '2024-03-15', 220.00),
(8, 1, '2024-04-01', 260.00),
(1, 3, '2024-04-10', 130.00),
(3, 4, '2024-04-15', 210.00),
(2, 5, '2024-04-20', 170.00),
(4, 1, '2024-05-01', 270.00),
(5, 2, '2024-05-05', 320.00),
(6, 3, '2024-05-10', 190.00),
(7, 4, '2024-05-15', 230.00),
(8, 5, '2024-05-20', 280.00);


-- Verifico che i campi definiti come PK siano univoci
-- Verifica univocità dei PK
SELECT COUNT(ID) AS Count_ID FROM Product;
SELECT COUNT(ID) AS Count_ID FROM Region;
SELECT COUNT(ID) AS Count_ID FROM Sales;

-- Espongo l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno
SELECT p.Nome, YEAR(s.Data) AS Anno, SUM(s.Fatturato) AS Fatturato_Totale
FROM Product p
INNER JOIN Sales s ON p.ID = s.ID_Prodotto
GROUP BY p.Nome, YEAR(s.Data);

-- Espongo il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente
SELECT r.Stato, YEAR(s.Data) AS Anno, SUM(s.Fatturato) AS Fatturato_Totale
FROM Region r
INNER JOIN Sales s ON r.ID = s.ID_Regione
GROUP BY r.Stato, YEAR(s.Data)
ORDER BY YEAR(s.Data), Fatturato_Totale DESC;

-- Categoria di articoli maggiormente richiesta dal mercato
SELECT p.Categoria, COUNT(*) AS Numero_Vendite
FROM Product p
INNER JOIN Sales s ON p.ID = s.ID_Prodotto
GROUP BY p.Categoria
ORDER BY Numero_Vendite DESC
LIMIT 1;

-- Quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi
-- Approccio 1: Utilizzo di LEFT JOIN
SELECT p.Nome
FROM Product p
LEFT JOIN Sales s ON p.ID = s.ID_Prodotto
WHERE s.ID IS NULL;

-- Approccio 2: Utilizzo di NOT IN
SELECT Nome
FROM Product
WHERE ID NOT IN (SELECT DISTINCT ID_Prodotto FROM Sales);

-- Espongo l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente):
SELECT p.Nome, MAX(s.Data) AS Ultima_Data_Vendita
FROM Product p
LEFT JOIN Sales s ON p.ID = s.ID_Prodotto
GROUP BY p.Nome;



